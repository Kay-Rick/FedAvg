# FL训练框架
- 创建自己的虚拟环境: `conda create -n xxx`
- 安装依赖: `conda install --yes --file requirements.txt`
- 修改config.py存放的数据集路径, 在data下面分别创建对应数据集的文件夹：例如cifar10_data,数据集会自动下载到该文件夹
- 运行mainAVG.py `python mainAVG.py`
